package com.supermarket.dao;

import java.util.List;

import com.supermarket.dto.Cart;
import com.supermarket.dto.Product;
import com.supermarket.dto.User;

public interface UserDao {
	
	void insertUser(User user);
	boolean checkUser(User user);
	List<Product> selectItem(Product product);
	void insertToCard(int userId,String productName,Product product,Cart cart,int qty );
	User selectUserDetails(User user);
	List<Cart> selectUserItem(int userId);
	void deleteItem(int cartId);
	Cart selectUpdateItem(int cartId);
	List<Cart>updateItem(Cart cart,int userId);
	String forgotPassword(String userEmail);
	List<User> selectAll();
}
