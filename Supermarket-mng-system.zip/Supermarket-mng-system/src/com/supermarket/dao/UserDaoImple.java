package com.supermarket.dao;


import org.hibernate.Transaction;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;


import com.supermarket.dto.Cart;
import com.supermarket.dto.Product;
import com.supermarket.dto.User;

@Repository
public class UserDaoImple implements UserDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	@Override
	public void insertUser(User user) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				org.hibernate.Transaction tr = session.beginTransaction();
				user.setUserType("Customer");
				session.save(user);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
		
	}
	@Override
	public boolean checkUser(User user) {
		
		boolean b=hibernateTemplate.execute(new HibernateCallback<Boolean>() {

			@Override
			public Boolean doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				
				Query q=session.createQuery("from User where userName=? and userPass=?");
				q.setString(0, user.getUserName());
				q.setString(1, user.getUserPass());
				List<User>li=q.list();
				Boolean flag= !li.isEmpty();
				tr.commit();
				session.flush();
				session.close();
				return flag;
			}
		});
		
		return b;
	}
	
	@Override
	public List<Product> selectItem(Product product) {
		List<Product>proList=hibernateTemplate.execute(new HibernateCallback<List<Product>>() {

			@Override
			public List<Product> doInHibernate(Session session) throws HibernateException {
				
				Transaction tr=session.beginTransaction();
				Query q=session.createQuery("from Product where productType=?");
				q.setString(0, product.getProductType());
				
				List<Product> li=q.list();
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		
		return proList ;
	}
	@Override
	public void insertToCard(int userId,String productName, Product product, Cart cart, int qty) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				cart.setUserId(userId);
				cart.setProductId(product.getProductId());
				cart.setPrice(product.getPrice());
				cart.setQuantity(qty);
				cart.setProductName(productName);
				session.save(cart);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
	
	}
	@Override
	public User selectUserDetails(User user) {
	User ur=	hibernateTemplate.execute(new HibernateCallback<User>() {

			@Override
			public User doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				Query q=session.createQuery("from User where userPass=? and userName=?");
				q.setString(0, user.getUserPass());
				q.setString(1, user.getUserName());
				//System.out.println("Abhi");
				//System.out.println(q.list());
				User user=(User)q.list().get(0);
				return user;
			}
		});
		return ur;
	}
	@Override
	public List<Cart> selectUserItem(int userId) {
		List<Cart>list=hibernateTemplate.execute(new HibernateCallback<List<Cart>>() {

			@Override
			public List<Cart> doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				Query q=session.createQuery("from Cart where userId=?");
				q.setInteger(0, userId);
				List<Cart>li=q.list();
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return list;
	}
	@Override
	public void deleteItem(int cartId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Cart cart = new Cart();
				cart.setCartId(cartId);
				session.delete(cart);
				//Query q=session.createQuery("delete from Cart Where productId=? and userId=?");
				//q.setInteger(0, productId);
				//q.setInteger(1, UserId);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
		
	}
	@Override
	public Cart selectUpdateItem(int cartId) {
		Cart cart= hibernateTemplate.execute(new HibernateCallback<Cart>() {

			@Override
			public Cart doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				Query q=session.createQuery("from Cart where cartId=?");
				q.setInteger(0, cartId);
				Cart cr=(Cart)q.list().get(0);
				tr.commit();
				session.flush();
				session.close();
				return cr;
			}
		});
		return cart;
	}
	@Override
	public List<Cart> updateItem(Cart cart,int userId) {
		List<Cart>list=hibernateTemplate.execute(new HibernateCallback<List<Cart>>() {

			@Override
			public List<Cart> doInHibernate(Session session) throws HibernateException {
				Transaction tr=session.beginTransaction();
				//"update Customer set name = :newName where name = :oldName";
				//update Student s set e=s.marks=50 where s.studentId=10;
				System.out.println(cart.getQuantity());
				System.out.println(cart.getCartId());
				//Query q=session.createQuery("update Cart c set c.quantity=? where c.cartId=?");
				//q.setInteger(0, cart.getQuantity());
				//q.setInteger(1, cart.getCartId());
				//Product ex=(Product)session.get(Product.class, product.getProductId());
				Cart car = (Cart)session.get(Cart.class, cart.getCartId());
				car.setQuantity(cart.getQuantity());
				
				Query q1=session.createQuery("from Cart where userId=?");
				q1.setInteger(0, userId);
				List<Cart>li=q1.list();
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
		});
		return list;
	}
	
	
	@Override
	public String forgotPassword(String userEmail) {
		String password = hibernateTemplate.execute(new HibernateCallback<String>() {

			@Override
			public String doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from User where userEmail = ?");
				q.setString(0, userEmail);
				List<User> li = q.list();
				String pass = null;
				if(!li.isEmpty())
				{
					pass = li.get(0).getUserPass();
					System.out.println("Abhi");
					System.out.println(pass);
				}
				tr.commit();
				session.flush();
				session.close();
				return pass;
			}
			
		});
		return password;
	}
	
	@Override
	public List<User> selectAll() {
		List<User> userList = hibernateTemplate.execute(new HibernateCallback<List<User>>() {

			@Override
			public List<User> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from User ");
				
				List<User> li = q.list();
			
			
				
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return userList;
	}

	
	
}
/*
 * 
 * public void deleteExpense(int expenseId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.delete(new Expense(expenseId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
 * hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				org.hibernate.Transaction tr = session.beginTransaction();
				user.setUserType("Customer");
				session.save(user);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}*/
