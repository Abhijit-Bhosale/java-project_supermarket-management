package com.supermarket.service;

import java.util.List;

import com.supermarket.dto.Cart;
import com.supermarket.dto.Product;
import com.supermarket.dto.User;

public interface UserService {
	void addUser(User user);
	boolean findUser(User user);
	List<Product> findItem(Product product);
	void addToCard(int userId,String productName,Product product,Cart cart,int qty);
	User findUserDetails(User user);
	List<Cart> findUserItem(int userId);
	void removeItem(int cartId);
	Cart selectModifyItem(int cartId);
	List<Cart> modifyItem(Cart cart,int userId);
	String forgotPassword(String userEmail);
	List<User> selectAllUser();
}
