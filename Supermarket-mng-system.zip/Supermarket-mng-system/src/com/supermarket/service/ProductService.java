package com.supermarket.service;

import java.util.List;

import com.supermarket.dto.Product;



public interface ProductService {
	void addProduct(Product product);
	void removeProduct(int productId);
	Product findProduct(int expenseId);
	
	void modifyProduct(Product product);
	List<Product> selectAll();
}
