package com.supermarket.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="cart")
public class Cart {
	@Id
	@GeneratedValue
	@Column(name="cart_id")
	private int cartId;
	@Column(name="user_id")
	private int userId;
	@Column(name="product_id")
	private int productId;
	private float price;
	private int quantity;
	@Column(name="product_name")
	private String productName;
	
	
	
	public Cart(int userId, int productId) {
		super();
		this.userId = userId;
		this.productId = productId;
	}
	public Cart(int productId) {
		super();
		this.productId = productId;
	}
	public Cart() {
		super();
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	
}
