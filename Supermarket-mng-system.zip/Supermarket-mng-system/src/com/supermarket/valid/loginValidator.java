package com.supermarket.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import java.util.regex.Matcher; 
import java.util.regex.Pattern; 

import com.supermarket.dto.User;

@Service
public class loginValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		
		return clazz.equals(User.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		User user=(User)target;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName","unmKey", "User Name is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPass","passKey", "Password is requird");	
		
		
		
		
	}
}
