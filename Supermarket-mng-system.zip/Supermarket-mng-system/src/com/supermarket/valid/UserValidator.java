package com.supermarket.valid;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import java.util.regex.Matcher; 
import java.util.regex.Pattern; 

import com.supermarket.dto.User;

@Service
public class UserValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		
		return clazz.equals(User.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		User user=(User)target;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName","unmKey", "User Name is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPass","passKey", "Password is requird");	
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userEmail","emailKey", "Email is requird");	
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPho","phKey", "Phone is requird");	
		
		
		
		if(user.getUserPass()!=null)
		{
			if(user.getUserPass().length()<3 || user.getUserPass().length()>5)
			{
				errors.rejectValue("userPass","passKey", "Password should contain 3 to 5 characters");
			}
		}
		
		if(user.getUserPho()!=null)
		{
			if(user.getUserEmail().length()>0)
			{
			    Pattern p = Pattern.compile("(0/91)?[7-9][0-9]{9}"); 		  
			    
			    Matcher m = p.matcher(user.getUserPho()); 
			    if (!(m.find() && m.group().equals(user.getUserPho()))) {
			    	errors.rejectValue("userPho","phKey", "Phone number is not valid");
			    }
			}
		}
		
		
		if(user.getUserEmail()!=null)
		{ 
			String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+ 
                "[a-zA-Z0-9_+&*-]+)*@" + 
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
                "A-Z]{2,7}$";                   
			Pattern pat = Pattern.compile(emailRegex); 
			
			if(user.getUserEmail().length()>0)
			{
				if(!pat.matcher(user.getUserEmail()).matches()) {
					errors.rejectValue("userEmail","emailKey", "Email id is not valid");
				} 
			}
		}		
	}

}
